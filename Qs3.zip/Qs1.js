let saraApples = 25;
let additionalApples = 15;
let totalApple = saraApples + additionalApples;
console.log('total apples Sara Has:', totalApple); 
// সারার মোট আপেল আছে 40টি। 


