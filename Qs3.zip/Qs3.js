let machinesPerHour = 120;
let totalHour = 8;
let totalMachines = machinesPerHour * totalHour
console.log('Total Machines made in 8 hours: ', totalMachines);
// উত্তর: কারখানাটি ৮ ঘন্টায় ৯৬০টি মেশিন তৈরি করে।
