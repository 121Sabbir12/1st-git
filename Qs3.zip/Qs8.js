let totalChocolate = 120;
let chocolatesPerPacket = 9;
let fullPackets = totalChocolate / chocolatesPerPacket;

let remainingChocolates = totalChocolate % chocolatesPerPacket;
console.log('Full Packets:', fullPackets);
console.log('Remaining Chocolates:', remainingChocolates);
// উত্তর: চকোলেট অবশিষ্ট আছে ৩টি। 