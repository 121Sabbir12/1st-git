let rohimOranges = 8;
let friendGivenOranges = 12;
let orangesLeft = rohimOranges - 1 + friendGivenOranges;
console.log('Oranges left with Rohim:', orangesLeft);
// উত্তর: রহিমের কাছে ১৯ টি কমলা আছে।
