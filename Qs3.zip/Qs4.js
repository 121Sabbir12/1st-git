let initialPlants = 25;
let addedPlants = 20;
let remaingPlants = initialPlants - 7 + addedPlants;
console.log('Total Plants remaining in the garden:', remaingPlants);
// উত্তর: বাগানে এখন মোট ৩৮টি গাছ থাকবে।
