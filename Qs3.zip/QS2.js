let johMoney = 500;
let spentMoney = 200;
let remainingMoney = johMoney - spentMoney;
console.log('Money left with Jon:',remainingMoney);
// জনের কাছে বাকি আছে ৩০০ টাকা। 