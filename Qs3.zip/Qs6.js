let totalDistance = 150;
let totalTime = 3;
let distancePerHour = totalDistance / totalTime;
console.log('Train covers per hour:', distancePerHour, 'km');

// উত্তর: ট্রেন প্রতি ঘন্টায় ৫০ কিলোমিটার পথ অতিক্রম করে।